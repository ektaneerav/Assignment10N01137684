# MySQL/PHP Demo

## Description

A simple teaching application for rendering SQL results returned from a local server via MySQL.

