function shiftDelete(shiftid)
{
	var conf = confirm("Are you sure?");
	if(conf === true){
		var xm = new XMLHttpRequest();
		xm.onreadystatechange = function()
		{
			if(this.readyState == 4 && this.status == 200) 
			{
				location.reload();
			}
		}
		xm.open("GET", shift_delete.php?sid="+ shiftid, true);
		xm.send();
	}
	else
	{
	}
}