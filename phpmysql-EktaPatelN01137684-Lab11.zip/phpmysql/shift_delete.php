<?php

require_once="config_connection.php";
	$sid = $_GET["shiftID"];
	
	$query = "DELETE FROM bakery_shifts WHERE shift_id = $sid";
	if($result = mysqli_query($link,$query)){
	echo "Shift Deleted";
	}
	else
	{
		echo $query;
	}
?>
